const apiServerDomain = 'https://sportshall-api.shop';
module.exports = {
    apiServerDomain,
}
